use strict;
use warnings;

# this test was generated with Dist::Zilla::Plugin::Test::Compile 2.059

use Test::More;

plan tests => 17 + ($ENV{AUTHOR_TESTING} ? 1 : 0);

my @module_files = (
    'Log/Any.pm',
    'Log/Any/Adapter.pm',
    'Log/Any/Adapter/Base.pm',
    'Log/Any/Adapter/Capture.pm',
    'Log/Any/Adapter/File.pm',
    'Log/Any/Adapter/Multiplex.pm',
    'Log/Any/Adapter/Null.pm',
    'Log/Any/Adapter/Stderr.pm',
    'Log/Any/Adapter/Stdout.pm',
    'Log/Any/Adapter/Syslog.pm',
    'Log/Any/Adapter/Test.pm',
    'Log/Any/Adapter/Util.pm',
    'Log/Any/Manager.pm',
    'Log/Any/Proxy.pm',
    'Log/Any/Proxy/Null.pm',
    'Log/Any/Proxy/Test.pm',
    'Log/Any/Test.pm'
);



# no fake home requested

my @switches = (
    -d 'blib' ? '-Mblib' : '-Ilib',
);

use File::Spec;
use IPC::Open3;
use IO::Handle;

open my $stdin, '<', File::Spec->devnull or die "can't open devnull: $!";

my @warnings;
for my $lib (@module_files)
{
    # see L<perlfaq8/How can I capture STDERR from an external command?>
    my $stderr = IO::Handle->new;

    diag('Running: ', join(', ', map { my $str = $_; $str =~ s/'/\\'/g; q{'}.$str.q{'} }
            $^X, @switches, '-e', "require q[$lib]"))
        if $ENV{PERL_COMPILE_TEST_DEBUG};

    my $pid = open3($stdin, '>&STDERR', $stderr, $^X, @switches, '-e', "require q[$lib]");
    binmode $stderr, ':crlf' if $^O eq 'MSWin32';
    my @_warnings = <$stderr>;
    waitpid($pid, 0);
    is($?, 0, "$lib loaded ok");

    shift @_warnings if @_warnings and $_warnings[0] =~ /^Using .*\bblib/
        and not eval { +require blib; blib->VERSION('1.01') };

    if (@_warnings)
    {
        warn @_warnings;
        push @warnings, @_warnings;
    }
}



is(scalar(@warnings), 0, 'no warnings found') or diag 'got warnings: ', ( Test::More->can('explain') ? Test::More::explain(\@warnings) : join("\n", '', @warnings) ) if $ENV{AUTHOR_TESTING};


